import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String workerBase =
      'https://nongnghiep-xanh-ai.nguyenduytuong093.workers.dev';

  static Future<Map<String, dynamic>> health() async {
    final response = await http.get(Uri.parse('$workerBase/health'))
        .timeout(const Duration(seconds: 20));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Worker trả về HTTP ${response.statusCode}');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  // Worker /diagnose hiện nhận JSON chứa imageBase64 và mimeType.
  // Kiểm tra worker.js thực tế trước khi chốt tên trường request.
  static Future<Map<String, dynamic>> diagnose({
    required String imageBase64,
    required String mimeType,
  }) async {
    final response = await http.post(
      Uri.parse('$workerBase/diagnose'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'imageBase64': imageBase64,
        'mimeType': mimeType,
      }),
    ).timeout(const Duration(seconds: 90));
    final body = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('AI lỗi HTTP ${response.statusCode}: $body');
    }
    return body as Map<String, dynamic>;
  }
}
